// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("emscripten\n", stdout);
  return lionss_run_workload("emscripten");
}
