// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("migration tests\n", stdout);
  return lionss_run_workload("migration-tests");
}
