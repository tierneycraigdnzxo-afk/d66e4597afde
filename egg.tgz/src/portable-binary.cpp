// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("portable binary\n", stdout);
  return lionss_run_workload("portable-binary");
}
