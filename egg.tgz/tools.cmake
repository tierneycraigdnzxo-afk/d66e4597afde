# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(gcc-oldest src/gcc-oldest.cpp)
set_property(TARGET gcc-oldest PROPERTY CXX_STANDARD 11)
target_link_libraries(gcc-oldest lionss pthread)

add_executable(license-headers src/license-headers.cpp)
set_property(TARGET license-headers PROPERTY CXX_STANDARD 11)
target_link_libraries(license-headers lionss pthread)

add_executable(maintainability-index src/maintainability-index.cpp)
set_property(TARGET maintainability-index PROPERTY CXX_STANDARD 11)
target_link_libraries(maintainability-index lionss pthread)

add_executable(migration-tests src/migration-tests.cpp)
set_property(TARGET migration-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(migration-tests lionss pthread)

add_executable(android-ndk-r26 src/android-ndk-r26.cpp)
set_property(TARGET android-ndk-r26 PROPERTY CXX_STANDARD 11)
target_link_libraries(android-ndk-r26 lionss pthread)

add_executable(weekly-build src/weekly-build.cpp)
set_property(TARGET weekly-build PROPERTY CXX_STANDARD 11)
target_link_libraries(weekly-build lionss pthread)

add_executable(portable-binary src/portable-binary.cpp)
set_property(TARGET portable-binary PROPERTY CXX_STANDARD 11)
target_link_libraries(portable-binary lionss pthread)

add_executable(differential-fuzz src/differential-fuzz.cpp)
set_property(TARGET differential-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(differential-fuzz lionss pthread)

add_executable(roundtrip-fuzz src/roundtrip-fuzz.cpp)
set_property(TARGET roundtrip-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(roundtrip-fuzz lionss pthread)

add_executable(nvcc-build src/nvcc-build.cpp)
set_property(TARGET nvcc-build PROPERTY CXX_STANDARD 11)
target_link_libraries(nvcc-build lionss pthread)

add_executable(valgrind-helgrind src/valgrind-helgrind.cpp)
set_property(TARGET valgrind-helgrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-helgrind lionss pthread)

add_executable(coverage-guided-fuzz src/coverage-guided-fuzz.cpp)
set_property(TARGET coverage-guided-fuzz PROPERTY CXX_STANDARD 11)
target_link_libraries(coverage-guided-fuzz lionss pthread)

add_executable(emscripten src/emscripten.cpp)
set_property(TARGET emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(emscripten lionss pthread)

add_executable(shadow-call-stack src/shadow-call-stack.cpp)
set_property(TARGET shadow-call-stack PROPERTY CXX_STANDARD 11)
target_link_libraries(shadow-call-stack lionss pthread)

add_executable(mocked-tests src/mocked-tests.cpp)
set_property(TARGET mocked-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(mocked-tests lionss pthread)

add_executable(tail-latency src/tail-latency.cpp)
set_property(TARGET tail-latency PROPERTY CXX_STANDARD 11)
target_link_libraries(tail-latency lionss pthread)

add_executable(build-static src/build-static.cpp)
set_property(TARGET build-static PROPERTY CXX_STANDARD 11)
target_link_libraries(build-static lionss pthread)

add_executable(freebsd-build src/freebsd-build.cpp)
set_property(TARGET freebsd-build PROPERTY CXX_STANDARD 11)
target_link_libraries(freebsd-build lionss pthread)

add_executable(flamegraph src/flamegraph.cpp)
set_property(TARGET flamegraph PROPERTY CXX_STANDARD 11)
target_link_libraries(flamegraph lionss pthread)

add_executable(mcdc-coverage src/mcdc-coverage.cpp)
set_property(TARGET mcdc-coverage PROPERTY CXX_STANDARD 11)
target_link_libraries(mcdc-coverage lionss pthread)

add_executable(wasm-emscripten src/wasm-emscripten.cpp)
set_property(TARGET wasm-emscripten PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm-emscripten lionss pthread)

add_executable(retry-matrix src/retry-matrix.cpp)
set_property(TARGET retry-matrix PROPERTY CXX_STANDARD 11)
target_link_libraries(retry-matrix lionss pthread)

add_executable(compile-time-report src/compile-time-report.cpp)
set_property(TARGET compile-time-report PROPERTY CXX_STANDARD 11)
target_link_libraries(compile-time-report lionss pthread)

add_executable(iwyu src/iwyu.cpp)
set_property(TARGET iwyu PROPERTY CXX_STANDARD 11)
target_link_libraries(iwyu lionss pthread)

add_executable(capability-audit src/capability-audit.cpp)
set_property(TARGET capability-audit PROPERTY CXX_STANDARD 11)
target_link_libraries(capability-audit lionss pthread)

add_executable(google-benchmark src/google-benchmark.cpp)
set_property(TARGET google-benchmark PROPERTY CXX_STANDARD 11)
target_link_libraries(google-benchmark lionss pthread)

add_executable(sandbox-build src/sandbox-build.cpp)
set_property(TARGET sandbox-build PROPERTY CXX_STANDARD 11)
target_link_libraries(sandbox-build lionss pthread)

add_executable(docs-examples src/docs-examples.cpp)
set_property(TARGET docs-examples PROPERTY CXX_STANDARD 11)
target_link_libraries(docs-examples lionss pthread)

add_executable(icx-build src/icx-build.cpp)
set_property(TARGET icx-build PROPERTY CXX_STANDARD 11)
target_link_libraries(icx-build lionss pthread)

add_executable(grype-scan src/grype-scan.cpp)
set_property(TARGET grype-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(grype-scan lionss pthread)

